#! /bin/sh
autoreconf -fiv
