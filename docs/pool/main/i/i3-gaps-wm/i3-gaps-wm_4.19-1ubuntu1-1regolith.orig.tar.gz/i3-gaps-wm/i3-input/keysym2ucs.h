#include <xcb/xcb.h>

long keysym2ucs(xcb_keysym_t keysym);
