aio.Connection
==============

.. autoclass:: i3ipc.aio.Connection
   :members:
   :undoc-members:
