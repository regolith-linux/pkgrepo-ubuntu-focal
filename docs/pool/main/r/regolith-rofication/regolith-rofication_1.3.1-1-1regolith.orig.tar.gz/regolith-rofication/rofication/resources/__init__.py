from ._static import __version__, value_font, notify_some, notify_none, notify_error, \
    value_color, label_color, critical_color, nominal_color, warning_color
